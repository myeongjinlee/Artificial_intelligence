# ML-Evangelism
### MSP Machine Learning Evangelism

#### 1. Lenear Regression (Boston Dataset)
#### 2. Logistic Regression (MNIST Dataset)
#### 3. Neural Network (MNIST Dataset)
#### 4. Azure ML Studio (Connected for MNIST Dataset pridicting)